# Ahmed Sghaier — portfolio

Static site (`index.html`) + mail backend (`api/contact.js`, Vercel + Gmail).
Trilingual (EN / FR / عربي, with RTL), real projects, case studies, CV, SEO.

## 1. Add this to your existing repo (ahmedsghaierr.github.io)
Copy `index.html`, `expense.html`, `invoice.html`, `robots.txt`, `sitemap.xml` into the repo root, and the new files `assets/og.png` and `assets/shots/` into your `assets/` folder. Keep your existing `assets/` and `cinevault.html`.
`expense.html` replaces your old Expense Tracker (new design; old saved entries won't carry over). Back up the old file first if you want to keep it.
The page expects `assets/your_picture.jpg` and `assets/cv.pdf` (you already have both).

## 2. Add screenshots (biggest visual upgrade)
Screenshots for Expense Tracker and Invoice Maker are included. Add `assets/shots/cinevault.jpg` yourself
(about 1280×720, under 150 KB), plus `assets/shots/invoice.jpg`. Until then a placeholder shows.

## 3. Fill the optional bits (top of the script in index.html, `EDIT THESE`)
- `AVAILABLE` — true/false for the green freelance badge
- `STATS` — your GoatCounter code (free at goatcounter.com) to count visitors; empty = no tracking
- `CERTS` — your training/certificates (section hidden while empty)
- `video` on a project — path to a short .mp4/.webm screen recording (replaces the screenshot)
- `SKILLS` — your real skill percentages (the current numbers are placeholders, C++ is a guess)
- `LINKEDIN` — your URL (hidden while empty)
- `repo` on each project — GitHub repo link (hidden while empty)
- `TESTIMONIALS` — real quotes only (section hidden while empty)

## 4. Deploy the mail backend (free, ~5 min)
1. Google Account → Security → 2-Step Verification on → App passwords → create → copy the 16 characters.
2. Put the `api/` folder + `package.json` in its own GitHub repo (or this whole folder) and import it on vercel.com.
3. Vercel → Settings → Environment Variables: `GMAIL_USER`, `GMAIL_APP_PASSWORD`, `TO_EMAIL`, `ALLOWED_ORIGIN`
   (`https://ahmedsghaierr.github.io`, plus your custom domain, comma-separated).
4. Redeploy, then paste `https://<project>.vercel.app/api/contact` into `API_URL` in `index.html`.
Never put the app password in the page. Until `API_URL` is set, the form opens the visitor's mail app.

## 5. Custom domain
Buy a domain (e.g. ahmedsghaier.dev), then repo Settings → Pages → Custom domain, and add the DNS records GitHub lists.
Afterwards update the URLs in `<link rel="canonical">`, the `og:` tags, the JSON-LD block, `robots.txt`, `sitemap.xml` and `ALLOWED_ORIGIN`.

## 6. Check quality
Open Chrome DevTools → Lighthouse → run on mobile. Compress images (squoosh.app) if performance is under 90.
